/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
  *******************************************************************************/

function createTree()
{
	var lists = document.getElementsByClassName("collapsibleList");

	for (var ulIndex = 0; ulIndex < lists.length; ulIndex++)
	{
		var lis = lists[ulIndex].getElementsByTagName("li");

		for (var liIndex = 0; liIndex < lis.length; liIndex++)
		{
			var nextElemLevel = 1;
			var currElem = lis[liIndex];
			if (liIndex < lis.length - 1)
			{
				nextElemLevel = lis[liIndex + 1].getAttribute("level");
			}
			
			var lvl = currElem.getAttribute("level");
			currElem.style.backgroundPosition = (lvl - 1) * 8 + "px 60%"
			currElem.style.paddingLeft = (lvl - 1) * 8 + 11 + "px"
			if (lvl < nextElemLevel)
			{
				currElem.setAttribute("id", "listsubmenu");
				currElem.onclick = function(event)
				{
					var children = getChildren(this);

					if (this.getAttribute("rel") == "closed")
					{
						this.setAttribute("rel", "open");
						this.style.backgroundImage = "url(tree/minus.gif)"
						expandElements(children);
					}
					else
					{
						this.setAttribute("rel", "closed");
						this.style.backgroundImage = "url(tree/plus.gif)"
						collapseElements(children);
					}
				}
			}
		}
	}
}

function expandElements(list)
{
	for (var i = 0; i < list.length; i++)
	{
		var elem = list[i];
		elem.style.display = "block";
		
		if (elem.getAttribute("id") == "listsubmenu")
		{
			elem.setAttribute("rel", "open");
			elem.style.backgroundImage = "url(tree/minus.gif)"
		}
	}
}

function collapseElements(list)
{
	for (var i = 0; i < list.length; i++)
	{
		list[i].style.display = "none";
	}
}

function getChildren(element)
{
	var found = false;
	var count = 0;
	
	// get all ULs in document
	var lists = document.getElementsByClassName("collapsibleList");	
	
	// find the index of the UL that contains 'element'
	for (var index = 0; index < lists.length; index++)
	{
		count++;
		var lis = lists[index].getElementsByTagName("li");
		for (var i = 0; i < lis.length; i++)
		{
			if (lis[i] == element)
			{
				found = true;
				break;
			}
		}
		if (found)
		{
			break;
		}
	}

	// find all children of 'element' from that particular UL
	lis = lists[count - 1].getElementsByTagName("li");
	found = false;

	var children = [];
	for (var j = 0; j < lis.length; j++)
	{
		if (found)
		{
			if (element.getAttribute("level") < lis[j].getAttribute("level"))
			{
				children.push(lis[j]);
			}
			else
			{
				break;
			}
		}
		
		if (lis[j] == element)
		{
			found = true;
		}
	}
	
	return children;
}